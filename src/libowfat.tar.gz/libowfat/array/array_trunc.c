#include "array.h"

void array_trunc(array* x) {
  x->initialized=0;
}
